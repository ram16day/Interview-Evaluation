package com.employe.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employe.entity.Employee;
import com.employe.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/createemp")
	public Employee createEmployee(@RequestBody Employee employee) {

		return employeeService.createEmployee(employee);
	}

	@GetMapping("/findempid/{id}")
	public Optional<Employee> findEmployee(@PathVariable int id) {

		return employeeService.findEmployee(id);
	}

	@GetMapping("/findbyname/{empName}")
	public Employee findEmployeeByName(@PathVariable String empName) {

		return employeeService.findEmployeeByName(empName);
	}

}
