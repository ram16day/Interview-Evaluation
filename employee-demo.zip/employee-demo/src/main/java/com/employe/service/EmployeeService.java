package com.employe.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employe.entity.Employee;
import com.employe.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public Employee createEmployee(Employee employee) {

		return employeeRepository.save(employee);
	}

	public Optional<Employee> findEmployee(int id) {

		return employeeRepository.findById(id);
	}

	public Employee findEmployeeByName(String empName) {

		return employeeRepository.findByEmpName(empName);
	}

}
